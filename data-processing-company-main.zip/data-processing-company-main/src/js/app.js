$(function () {

//===== User scripts:

@@include('scripts/smooth-scroll.js')

@@include('scripts/touch.js')

@@include('scripts/mmenu.js')

@@include('scripts/reasons__modal.js')

@@include('scripts/dynamic-adapt.js')

@@include('scripts/toTop-button.js')

@@include('scripts/animated-scrolling.js')
});
